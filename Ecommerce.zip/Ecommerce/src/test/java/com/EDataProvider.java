package com;

import org.testng.annotations.DataProvider;

public class EDataProvider {

	@DataProvider(name = "SearchProduct")
	public String[][] getProduct() {
		String products[][] = new String[1][1];
		products[0][0] = "1052250";
		return products;
	}

	@DataProvider(name = "InvalidProduct")
	public String[][] getFBMessage() {
		String products[][] = new String[1][1];
		products[0][0] = "xyz123";
		return products;
	}
}
