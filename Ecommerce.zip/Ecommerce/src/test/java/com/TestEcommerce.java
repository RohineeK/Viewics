package com;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.initialiser.Initialiser;
import com.initialiser.Variables;
import com.pages.CartPage;
import com.pages.HomePage;
import com.pages.ProductPage;
import com.pages.WishlistPage;
import com.utilities.CommonActions;
import com.utilities.ReportGenerator;

public class TestEcommerce {
	ReportGenerator report = new ReportGenerator();

	@BeforeSuite
	public void startTestCase() {
		Initialiser.initialise();
		Initialiser.initialiseBrowser();
		report.startReport();
		Initialiser.driver.get(Variables.URL);
	}

	@BeforeMethod
	public void beforeTestCase(Method method) {
		report.startTestCase(method.getName());
	}

	HomePage home = new HomePage();
	ProductPage product = new ProductPage();
	WishlistPage wishlist = new WishlistPage();
	CartPage cart = new CartPage();

	@Test(priority = 0)
	public void login() {
		home.login(Variables.Username, Variables.Password);
	}

	@Test(dataProvider = "SearchProduct", dataProviderClass = EDataProvider.class)
	public void testAValidProduct(String productName) {
		home.searchProduct(productName);
		String ptoductTitle = product.getProductTitle();

		product.selectSize("L");
		product.addToWishList();
		String buttonTextExp = "WISHLISTED";
		String buttonTextAct = product.getButtonText();
		CommonActions.verifyValue(buttonTextAct, buttonTextExp);

		product.gotoWishlist();

		String actualName = wishlist.getDesiredItemName(ptoductTitle);
		CommonActions.verifyValueContains(actualName, ptoductTitle);

		wishlist.moveToBag();
		home.gotoBag();
		String cartPageTitleExp = "SHOPPING BAG";
		String cartPageTitleAct = Initialiser.driver.getTitle();
		CommonActions.verifyValue(cartPageTitleAct, cartPageTitleExp);

		cart.removeFromCart();
		Initialiser.driver.get(Variables.URL);
	}

	@Test
	public void testAddRemoveWislist() {
		String productName = "10360555";
		home.searchProduct(productName);
		String ptoductTitle = product.getProductTitle();

		product.addToWishList();
		product.gotoWishlist();

		String actualName = wishlist.getDesiredItemName(ptoductTitle);
		CommonActions.verifyValueContains(actualName, ptoductTitle);

		wishlist.removeItem();

	}

	@Test(dataProvider = "InvalidProduct", dataProviderClass = EDataProvider.class)
	public void testInvalidProduct(String productName) {
		home.searchProduct(productName);
		String actualError = product.getNotFoundError();
		String expectedError = " We couldn't find any matches! ";
		CommonActions.verifyValue(actualError, expectedError);
	}

	@Test
	public void testFailed() {
		String actualPlaceholder = home.getInputPlaceholder();
		String expectedPlaceholder = "Wrong Placeholder";
		CommonActions.verifyValue(actualPlaceholder, expectedPlaceholder);
	}

	@AfterMethod
	public void backToHomePage() {
		home.clickLogo();
	}

	@AfterSuite
	public void tearDown() {
		report.endReport();
		Initialiser.driver.close();
	}

}
