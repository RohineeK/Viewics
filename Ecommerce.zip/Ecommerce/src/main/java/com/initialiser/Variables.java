package com.initialiser;

public class Variables {

	public static String ChromedriverPath;

	public static String ReportPath;
	public static String SceenshotPath;
	public static String PropertyFilePath="configs/configs.properties";
	public static String Browser;
	public static String URL;
	public static String Username;
	public static String Password;
}
