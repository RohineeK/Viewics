package com.initialiser;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import com.utilities.PropertiesReader;

public class Initialiser {

	public static WebDriver driver;

	public static void initialise() {
		Variables.ChromedriverPath = PropertiesReader.readProperties(Variables.PropertyFilePath, "ChromedriverPath");
		Variables.SceenshotPath = PropertiesReader.readProperties(Variables.PropertyFilePath, "SceenshotPath");
		Variables.ReportPath = PropertiesReader.readProperties(Variables.PropertyFilePath, "ReportPath");
		Variables.Browser = PropertiesReader.readProperties(Variables.PropertyFilePath, "Browser");
		Variables.URL = PropertiesReader.readProperties(Variables.PropertyFilePath, "URL");
		Variables.Browser = PropertiesReader.readProperties(Variables.PropertyFilePath, "Browser");
		Variables.Username = PropertiesReader.readProperties(Variables.PropertyFilePath, "Username");
		Variables.Password = PropertiesReader.readProperties(Variables.PropertyFilePath, "Password");
	}

	public static void initialiseBrowser() {
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver", Variables.ChromedriverPath);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
}
