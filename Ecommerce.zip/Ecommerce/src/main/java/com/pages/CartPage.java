package com.pages;

import org.openqa.selenium.By;

import com.utilities.CommonActions;

public class CartPage {
	private By removeButton = By.xpath("//button[contains(@class, 'removeButton')]");
	private By removeOnAlert = By.xpath("//*[@id='cartItemsList']/div/div/div/div[3]/div/div[2]/div/div[2]/button");

	public void removeFromCart()
	{
		CommonActions.findAndHighlight(removeButton, "removeButton").click();
		CommonActions.findAndHighlight(removeOnAlert, "removeOnAlert").click();
		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
