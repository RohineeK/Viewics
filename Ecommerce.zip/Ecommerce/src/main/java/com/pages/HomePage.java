package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.initialiser.Initialiser;
import com.utilities.CommonActions;

public class HomePage {
	private By searchInputBy = By.xpath("//div/input");
	private By searchButton = By.xpath("//div/a[@class='desktop-submit']");
	private By profile = By.xpath("//span[text()='Profile']");
	private By loginLink = By.xpath("//div/a[@data-track='login']");
	private By userID = By.name("email");
	private By passwordBy = By.name("password");
	private By loginButton = By.xpath("//button[text()='Log in']");
	private By logo = By.xpath("//div[@class='desktop-logoContainer']/a");
	private By bag = By.xpath("//a/span[text()='Bag']");
	
	public void gotoBag()
	{
		CommonActions.findAndHighlight(bag, "bag").click();
	}
	
	public void clickLogo() {
		CommonActions.findAndHighlight(logo, "ClickLogo").click();
	}

	public void login(String userName, String password) {
		Actions acts = new Actions(Initialiser.driver);
		Action act = acts.moveToElement(CommonActions.findAndHighlight(profile, "profile")).build();
		act.perform();
		CommonActions.findAndHighlight(loginLink, "loginLink").click();
		CommonActions.findAndHighlight(userID, "userID").sendKeys(userName);
		CommonActions.findAndHighlight(passwordBy, "passwordBy").sendKeys(password);
		CommonActions.findAndHighlight(loginButton, "loginButton").click();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void searchProduct(String productName) {
		CommonActions.findAndHighlight(searchInputBy, "searchInputBy").sendKeys(productName);
		CommonActions.findAndHighlight(searchButton, "searchButton").click();
	}
	
	public String getInputPlaceholder()
	{
		return CommonActions.findAndHighlight(searchInputBy, "searchInputBy").getAttribute("placeholder");
	}
}
