package com.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.initialiser.Initialiser;
import com.utilities.CommonActions;

public class WishlistPage {
	private By itemsList = By.xpath("//div[contains(@id, 'item')]");
	private By removeIcon = By.xpath("//div[@class='itemcard-removeIcon']");
	private By movetoBagLink = By.linkText("MOVE TO BAG");
	private By doneLink = By.linkText("DONE");
	
	public String getDesiredItemName(String itemName) {
		List<WebElement> items = Initialiser.driver.findElements(itemsList);
		String expItemName = null;
		if (items.size() == 0)
			expItemName = null;
		else if (items.size() == 1)
			expItemName = Initialiser.driver.findElement(By.xpath("//div[@id='item" + 0 + "']/div[3]/div[1]/div[1]"))
					.getText();
		else {
			for (WebElement ele : items) {
				int i = 0;
				String actualName = Initialiser.driver
						.findElement(By.xpath("//div[@id='item" + i + "']/div[3]/div[1]/div[1]")).getText();
				if (actualName.contains(itemName)) {
					expItemName = actualName;
					break;
				}
			}
		}
		return expItemName;
	}

	public void removeItem()
	{
		CommonActions.findAndHighlight(removeIcon, "removeIcon").click();
	}

	public void moveToBag()
	{
		CommonActions.findAndHighlight(movetoBagLink, "movetoBagLink").click();
		CommonActions.findAndHighlight(doneLink, "doneLink").click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}