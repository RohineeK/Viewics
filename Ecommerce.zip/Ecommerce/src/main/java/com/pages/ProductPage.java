package com.pages;

import org.openqa.selenium.By;

import com.utilities.CommonActions;

public class ProductPage {
	String size;
	private By sizeBy = By.xpath("//*[@id='sizeButtonsContainer']//p[text()='" + size + "']");
	//private By addToBagButton = By.xpath("//div[text()='ADD TO BAG']");
	private By addToWishlistButton = By.xpath("//span[text()='WISHLIST']");
	private By wishlistedButton = By.xpath("//span[text()='WISHLISTED']");
	private By wishlistLink = By.xpath("//a/span[text()='Wishlist']");
	private By productTitle = By.xpath("//div/h1[@class='pdp-title']");
	private By notFoundError = By.xpath("//*[@id='mountRoot']/div/center/div[1]/p[2]");

	public String getButtonText()
	{
		return CommonActions.findAndHighlight(wishlistedButton, "wishlistedButton").getText();
	}
	public String getProductTitle() {
		return CommonActions.findAndHighlight(productTitle, "productTitle").getText();
	}

	public String getNotFoundError() {
		return CommonActions.findAndHighlight(notFoundError, "NotFoundError").getText();
	}

	public void selectSize(String size) {
		this.size = size;
		sizeBy = By.xpath("//*[@id='sizeButtonsContainer']//p[text()='" + size + "']");
		CommonActions.findAndHighlight(sizeBy, "sizeBy").click();
		//CommonActions.findAndHighlight(addToBagButton, "addToBagButton").click();
	}

	public void addToWishList() {
		CommonActions.findAndHighlight(addToWishlistButton, "addToWishlistButton").click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void gotoWishlist() {
		CommonActions.findAndHighlight(wishlistLink, "wishlistLink").click();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
