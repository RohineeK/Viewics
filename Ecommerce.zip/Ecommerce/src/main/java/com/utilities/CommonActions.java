package com.utilities;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.initialiser.Initialiser;

public class CommonActions {

	static Logger log = Logger.getLogger(CommonActions.class.getName());
	static ReportGenerator report = new ReportGenerator();

	public static WebElement findAndHighlight(By by, String objectName) {
		// Initialiser.driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		// Initialiser.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// WebDriverWait wait = new WebDriverWait(Initialiser.driver, 30);
		// WebElement ele =
		// wait.until(ExpectedConditions.visibilityOfElementLocated(by));

		HighlightObject highlight = new HighlightObject();
		WebElement ele = Initialiser.driver.findElement(by);
		highlight.highLightElement(ele, objectName);
		return ele;
	}

	public static void click(By by, String objectName) {

		findAndHighlight(by, objectName).click();
	}

	public static Select selectDropDown(By by, String objectName) {
		WebElement dropDown = findAndHighlight(by, objectName);
		dropDown.click();
		Select sel = new Select(dropDown);
		return sel;
	}

	public static void selectDDbyValue(By by, String objectName, String value) {
		Select sel = selectDropDown(by, objectName);
		sel.selectByValue(value);
	}

	public static void selectDDbyIndex(By by, String objectName, int index) {
		Select sel = selectDropDown(by, objectName);
		sel.selectByIndex(index);
	}

	public static void selectDDbyText(By by, String objectName, String text) {
		Select sel = selectDropDown(by, objectName);
		sel.selectByVisibleText(text);
	}

	public static void selectRadioButton(By by, String objectName) {
		findAndHighlight(by, objectName).click();
	}

	public static void setValue(By by, String objectName, String value) {
		findAndHighlight(by, objectName).sendKeys(value);
	}

	public static String getValue(By by, String objectName) {
		String value = findAndHighlight(by, objectName).getText();
		return value;
	}

	public static String getRandomString(int length) {
		boolean useLetters = true;
		boolean useNumbers = false;
		return RandomStringUtils.random(length, useLetters, useNumbers);

	}

	public static boolean verifyValue(String actualValue, String expectedValue) {
		boolean flag;
		log.info(" Expected Value is: " + expectedValue.trim() + " ");
		log.info(" Actual Value is: " + actualValue.trim() + " ");
		if (actualValue.trim().equals(expectedValue.trim())) {
			flag = true;
			report.passTestStep("Displayed value '" + actualValue.trim() + "' is matching with Expected value '"
					+ expectedValue.trim() + "'");
			log.info(" Actual and Expected Values are matching ");
		} else {
			flag = false;
			report.failTestStep("Displayed value '" + actualValue.trim() + "' is NOT matching with Expected value '"
					+ expectedValue.trim() + "'");
			log.error(" Actual and Expected Values are NOT matching ");
		}
		Assert.assertEquals(actualValue.trim(), expectedValue.trim());
		return flag;
	}

	public static boolean verifyValueContains(String actualValue, String expectedValue) {
		boolean flag;
		log.info(" Expected Value is: " + expectedValue.trim() + " ");
		log.info(" Actual Value is: " + actualValue.trim() + " ");
		if (actualValue.trim().contains(expectedValue.trim())) {
			flag = true;
			report.passTestStep("Displayed value '" + actualValue.trim() + "' contains Expected value '"
					+ expectedValue.trim() + "'");
		} else {
			flag = false;
			report.failTestStep("Displayed value '" + actualValue.trim() + "' does NOT contain Expected value '"
					+ expectedValue.trim() + "'");
		}
		Assert.assertTrue(flag);
		return flag;
	}
	
	public static boolean isPresent(By by, String objectName) {
		boolean flag = false;

		flag = findAndHighlight(by, objectName).isDisplayed();
		if (flag)
			report.passTestStep(objectName + " is displayed on screen '");
		else
			report.failTestStep(objectName + " is NOT displayed on screen '");
		return flag;
	}
}
