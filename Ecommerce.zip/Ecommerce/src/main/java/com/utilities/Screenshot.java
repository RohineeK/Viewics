package com.utilities;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.initialiser.Initialiser;
import com.initialiser.Variables;


public class Screenshot {

	static Logger log = Logger.getLogger(Screenshot.class.getName());
	
	static WebDriver driver = Initialiser.driver;
	public static String takeScreenShot(String fileName) {

		String completeFilePath = null;
		// Convert web driver object to TakeScreenshot
		TakesScreenshot scrShot = ((TakesScreenshot) driver);

		// Call getScreenshotAs method to create image file

		File SrcFile = scrShot.getScreenshotAs(OutputType.FILE);
		
		try {
			Date d = new Date();
			DateFormat df = new SimpleDateFormat("yyyy_dd_MM");
			
			String screenshotPath = Variables.SceenshotPath + "_" + df.format(d);

			File dir = new File("" + screenshotPath);
			dir.mkdirs();
			
			DateFormat df1 = new SimpleDateFormat("yyyy_dd_MM HHmmss");
			
			String onlyFileName = fileName + "_" + df1.format(d) + ".JPG";
			completeFilePath = screenshotPath + "/" + onlyFileName;
			File permfile = new File(dir, onlyFileName);
			permfile.createNewFile();
			log.info("============== File generated " + permfile.getName() + " ==============");

			// Copy file at destination
			FileUtils.copyFile(SrcFile, permfile);

			
		} catch (Exception k) {
			k.printStackTrace();
			log.error("============== screenshot not generated " + k.getMessage() + " ==============");
		}

		log.info("============ Screenshot Taken ============");
		return completeFilePath;
	}

}
