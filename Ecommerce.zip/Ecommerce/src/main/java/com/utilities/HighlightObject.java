package com.utilities;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.initialiser.Initialiser;


public class HighlightObject {

	public void highLightElement(WebElement element, String objectName) {
		JavascriptExecutor js = (JavascriptExecutor) Initialiser.driver;
		
		//js.executeScript("arguments[0].scrollIntoView();", element);
		js.executeScript("arguments[0].setAttribute('style', 'background: white; border: 3px solid lime;');", element);
		ReportGenerator report = new ReportGenerator();
		String completePath = Screenshot.takeScreenShot(objectName);
	
		report.attachScreenshot("Performing action on " + objectName, completePath);
		
		js.executeScript("arguments[0].setAttribute('style',arguments[1]);", element, "");
	}
}
