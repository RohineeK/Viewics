package com.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.log4j.Logger;

public class PropertiesReader {
	static Logger log = Logger.getLogger(PropertiesReader.class.getName());
	public static String readProperties(String propertyFile, String property) {

		Properties prop = new Properties();
		InputStream input = null;

		try {

			input = new FileInputStream(propertyFile);

			// load a properties file
			prop.load(input);

			// get the property value and return same
			String property_value = prop.getProperty(property);
			log.info("Reading property: " + property + " In property File " + propertyFile + "\n\t Value is " + property_value);
			return property_value;

		} catch (IOException ex) {
			ex.printStackTrace();
			log.error("Properties file not found");
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return "Properties File not found";
	}
}
