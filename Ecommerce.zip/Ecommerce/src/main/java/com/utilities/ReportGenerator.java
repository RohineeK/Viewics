package com.utilities;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.ITestResult;

import com.initialiser.Variables;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
//import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ReportGenerator {

	Logger log = Logger.getLogger(ReportGenerator.class.getName());
	Listner listener = new Listner();

	// builds a new report using the html template
	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;

	// helps to generate the logs in test report.
	public static ExtentTest logger;

	public void startReport() {
		// initialize the HtmlReporter
		File file = new File(Variables.ReportPath);
		if (!file.exists()) {
			try {
				file.getParentFile().mkdir();
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// initialize the HtmlReporter
		htmlReporter = new ExtentHtmlReporter(Variables.ReportPath);

		// initialize ExtentReports and attach the HtmlReporter
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		// To add system or environment info by using the setSystemInfo method.
		extent.setSystemInfo("OS", "Windows");

		String browserName = Variables.Browser;
		extent.setSystemInfo("Browser", browserName);

		// configuration items to change the look and feel
		// add content, manage tests etc
		// htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("Test_Report_Banca");
		htmlReporter.config().setReportName("Automation Test Report");
		// htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setTimeStampFormat("EEEE, MMMM dd, yyyy, hh:mm a '('zzz')'");
	}

	public void startTestCase(String tesCaseID) {
		logger = extent.createTest(tesCaseID, "****** Test Case execution Started ******");
		log.info("****************************************************************************************");
		log.info("$$$$$$$$$$$$$$$$$$$$$                 " + tesCaseID + "       $$$$$$$$$$$$$$$$$$$$$$$$$");
		log.info("****************************************************************************************");
	}

	public void attachScreenshot(String testStep, String screenshotPath) {
		try {
			log.info("Attaching screenshot from path: " + screenshotPath);
			// logger.addScreenCaptureFromPath(screenshotPath);
			logger.log(Status.INFO, testStep,
					MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath.replace("Result/", "")).build());
		} catch (IOException e) {
			e.printStackTrace();
			log.error("Caught IO Exception: " + e.getMessage());
		}
	}

	public void passTest() {
		logger.pass("****** Test Case Passed ******");
		log.info("Test Case Passed");
	}

	public void failTest() {
		logger.fail("****** Test Case FAILED  ******");
		log.error("Test Case FAILED");
	}

	public void passTestStep(String message) {
		logger.pass(message);
		log.info("Test Step Passed: " + message);
	}

	public void failTestStep(String message) {
		logger.fail(message);
		log.error("Test Step FAILED: " + message);
	}

	public void skipTest(String testCaseName) {
		logger.skip("Skipping - This is not ready for testing " + testCaseName);
		log.warn("Skipping the Test Case: " + testCaseName);
	}

	public void logInfo(String message) {
		logger.log(Status.INFO, message);
	}

	public void logWarning(String message) {
		logger.log(Status.WARNING, message);
	}

	public void logError(String message) {
		logger.log(Status.ERROR, message);
	}

	public String getResult(ITestResult result, String sheetName, int rowNumber) {
		if (result.getStatus() == ITestResult.FAILURE) {
			listener.onTestFailure(result);
			logger.log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " FAILED ", ExtentColor.RED));
			return "FAILED";
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			listener.onTestSuccess(result);
			logger.log(Status.PASS, MarkupHelper.createLabel(result.getName() + " PASSED ", ExtentColor.GREEN));
			return "PASS";
		} else {
			listener.onTestSkipped(result);
			logger.log(Status.SKIP, MarkupHelper.createLabel(result.getName() + " SKIPPED ", ExtentColor.ORANGE));
			return "SKIPPED";
		}
	}

	public void endReport() {
		// to write or update test information to reporter
		log.info("Report Generated Successfully.");
		extent.flush();
	}
}